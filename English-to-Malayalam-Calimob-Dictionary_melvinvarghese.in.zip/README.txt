English–Malayalam StarDict dictionary for CaliMob

Archive contents:
- english_malayalam.ifo
- english_malayalam.idx
- english_malayalam.dict

Source: Olam English–Malayalam dictionary dataset
Source page: https://olam.in/p/open/enml
Source archive supplied: enml.tar.gz (contains files/enml, a UTF-8 tab-separated dataset)
License: ODbL as stated on the Olam dataset page. Please consult the source page for attribution and share-alike obligations.

This archive converts the tab-separated English-to-Malayalam data into StarDict 2.4.2 format.
